// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class CasteloNegro extends Actor
{

    /**
     * 
     */
    public CasteloNegro()
    {
        getImage().scale(300, 300);
    }

    /**
     * Act - do whatever the CasteloNegro wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void MeuAtor()
    {
    }
}
