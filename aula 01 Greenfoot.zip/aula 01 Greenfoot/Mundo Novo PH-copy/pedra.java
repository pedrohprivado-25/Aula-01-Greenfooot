// WARNING: This file is auto-generated and any changes to it will be overwritten
import lang.stride.*;
import java.util.*;
import greenfoot.*;

/**
 * 
 */
public class pedra extends Actor
{

    /**
     * 
     */
    public pedra()
    {
        getImage().scale(100, 100);
    }

    /**
     * Act - do whatever the pedra wants to do. This method is called whenever the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
    }
}
